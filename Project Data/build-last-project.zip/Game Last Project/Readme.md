# Game Hero of Pandemy

## Cara Bermain
* Movement dengan ASDW
* Shoot dengan L
* Ada 3 gelombang dengan keterangan :
  * Gelombang 1 memiliki 5 musuh
  * Gelombang 2 memiliki 8 musuh
  * Gelombang 3 memiliki 10 musuh
  * Jarak interval waktu tiap gelombang 8 detik

## Notice
* Damage tembakan musuh dikurangi menjadi 20 -> 5 agar test bisa mencapai wave terakhir
* Untuk animasi belum sepenuhnya selesai dikerjakan
* Spawn Enemy per Wave tidak menggunakan Object Pooling